echo Running setup.sh
### Pypi packages
pip install struct
###
echo Optionally include this script to install dependencies
echo Setup Complete
