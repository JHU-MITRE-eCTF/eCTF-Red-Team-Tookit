echo Running setup.sh
echo Optionally include this script to install dependencies
echo Setup Complete
